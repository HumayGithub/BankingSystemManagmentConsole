﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingSystemConsole
{
    class Program : Account
    {
        static void Main(string[] args)
        {
            enumPart ActiveDay = new enumPart();
            int n;
            Entry entry = new Entry();
            Account acc = new Account();
            entry.load();
            Console.Clear();
            entry.Show_intro();
            Console.Write("\n\nBank Active days Are following");
            ActiveDay.Showactivedays();
            do
            {
                Console.Write("\n\n\tMain Menu");
                Console.Write("\n\n\t01 New Account");
                Console.Write("\n\n\t02 Deposit Amount");
                Console.Write("\n\n\t03 Withdraw Amount");
                Console.Write("\n\n\t04 Balance Enquiry");
                Console.Write("\n\n\t05 All Account Holders List");
                Console.Write("\n\n\t06 Modify An Account");
                Console.Write("\n\n\t07 Exit");
                Console.WriteLine("\n\tSelect your option");
                n = int.Parse(Console.ReadLine());
                Console.Clear();
                switch (n)
                {
                    case 1:
                        {
                            Console.Clear();
                            entry.load();
                            acc.Public_createaccount();
                            break;
                        }
                    case 2:
                        {
                            Console.Clear();
                            entry.load();
                            acc.accountdep();
                            break;
                        }
                    case 3:
                        {
                            Console.Clear();
                            entry.load();
                            acc.accountWithdraw();
                            break;
                        }
                    case 4:
                        {
                            Console.Clear();
                            entry.load();
                            acc.account_report();
                            break;
                        }
                    case 5:
                        {
                            Console.Clear();
                            entry.load();
                            acc.Public_ShowAccount();
                            break;
                        }
                    case 6:
                        {
                            Console.Clear();
                            entry.load();
                            Console.WriteLine("Enter the Account No. :");
                            acc.Public_modify_account();
                            break;
                        }
                }
            }
            while (n != 7);//end of loop

        }
    }

}
