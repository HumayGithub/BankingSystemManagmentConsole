﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingSystemConsole
{
    class enumPart
    {
        enum Bankdays
        {
            Monday = 1, Thuesday = 2, Wennesday = 3, Thursday = 4, Friday = 5, Saturday = 0, Sunday = 0
        }
        int a = (int)Bankdays.Monday;
        int b = (int)Bankdays.Thuesday;
        int c = (int)Bankdays.Wennesday;
        int d = (int)Bankdays.Thursday;
        int e = (int)Bankdays.Friday;
        int f = (int)Bankdays.Saturday;
        int g = (int)Bankdays.Sunday;

        public void Showactivedays()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\nMonday={0}",a);
            Console.WriteLine("Thuesday={0}",b);
            Console.WriteLine("Wednesday={0}",c);
            Console.WriteLine("Thursday={0}",d);
            Console.WriteLine("Friday={0}",e);
            Console.WriteLine("Saturday={0}",f);
            Console.WriteLine("Sunday={0}", g);
            Console.ResetColor();
        }
    }
}
