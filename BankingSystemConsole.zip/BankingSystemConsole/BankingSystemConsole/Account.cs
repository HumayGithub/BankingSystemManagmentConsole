﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingSystemConsole
{
    class Account
    {
        private int acno;
        public int useracno
        {
            get { return acno; }
            set
            {
               if(value>1000 && value < 9999)
                {
                    acno = value;
                }
               else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("It is not valid Account Number");
                    Console.ResetColor();
                    System.Environment.Exit(1);
                }
               
            }
        }
        protected string name;
        internal int deposit;
        protected internal char type;
        private  void create_account()
        {
            Console.WriteLine("\nEnter The Account No. :");
            Console.WriteLine("The Account range from 1000 to 9999");
            useracno = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter The Name of the account Holder: ");
            name = Console.ReadLine();
            Console.WriteLine("Enter Type of the Account (C/S): ");
            type = char.Parse(Console.ReadLine());
            Console.WriteLine("Enter the Initail amount (>=500 for Saving and >=1000 for current): ");
            deposit = int.Parse(Console.ReadLine());
            Console.WriteLine("\nAccount Created....");
        }



        public void Public_createaccount()
        {
            create_account();
        }

        protected void show_Account()
        {
            Console.WriteLine("Account No. :{0}", useracno );
            Console.WriteLine("Account Holder Name: {0}" , name);
            Console.WriteLine("Type of Account: {0}", type);
            Console.WriteLine("Balance amount : {0}", deposit);
        }
        public void Public_ShowAccount()
        {
            show_Account();
        }
        private void ModifyAccount()
        {
            Console.WriteLine("Account No. :{0}", useracno);
            Console.WriteLine("Modify Account Holder Name: ");
            name = Console.ReadLine();
            Console.Write("Modify Type of Account :  ");
            type =char.Parse(Console.ReadLine());
            Console.WriteLine("Modify Type of Account : ");
            deposit = int.Parse(Console.ReadLine());
        }
        public void Public_modify_account()
        {
            ModifyAccount();
        }
        public void accountdep()
        {
            int x;
            Console.WriteLine("Enter the amount u want to Deposit");
            x = int.Parse(Console.ReadLine());
            deposit -= x;
        }
        public void accountWithdraw()
        {
            int x;
            Console.WriteLine("Enter the amount u want to Widthdraw");
            x = int.Parse(Console.ReadLine());
            deposit += x;
        }
        public void account_report()
        {
            Console.Write(" Acno :: "+ acno +" Name:: " + name +" Type:: " + type +"  deposit: "+ deposit);
        }
      
        
    }


   
}
