﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingSystemConsole
{
    struct Entry
    {
        private void intro()
        {
            Console.WriteLine("\n\nBank_Management_System");
            Console.WriteLine("\n\nMade By : Humay Rza");
        }
        public void Show_intro()
        {
            intro();
        }
        internal void load()
        {
            Console.Write("Loading");
            for(int i=0; i < 5; i++)
            {
                Console.Write(".");
                System.Threading.Thread.Sleep(500);
            }
        }
    }
}
